<!-- website footer
/*
*Title: Sam francis source code
*    Author: Francis, S
*    Date: 2017
*    Code version: 1
*    Availability: https://codepen.io/hollowsamff/pen/PjxMvQ
*/   -->
        <footer  class="navbar-fixed-bottom" style=" background-color:black;width:100%;">
            <div class="row">
                <div class="col-lg-12">
                    <p style = "color:#fff">Copyright &copy;
					<?php echo date("Y");
					?> Sam Franis</p>
					  
					  <p>
					  <a style="color:white; " href ="termsandconditions.php">Terms and conditions</a>
					  <a style="color:white;" href ="privacypolicy.php">Privacy policy</a></p>
					  
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </footer>		
	<script src='https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js'></script>
	  
</body>

</html>
